# Malay Words 🇲🇾

A simple Flutter app for learning Malay vocabulary.

## Features
- Malay words with English meanings and example sentences
- Search in Malay or English
- Save favourite words
- Add your own words
- Quick multiple-choice quiz
- Saves vocabulary locally using SharedPreferences

## Build an Android APK

1. Install Flutter and Android Studio.
2. Extract this project ZIP.
3. Open a terminal in this project folder.
4. Run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
5. Find the APK at:
   `build/app/outputs/flutter-apk/app-release.apk`

This ZIP is the Flutter project source, not an APK. An APK must be compiled with the Android/Flutter build tools.
