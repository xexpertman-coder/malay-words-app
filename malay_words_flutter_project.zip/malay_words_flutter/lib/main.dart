import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MalayApp());

class MalayApp extends StatelessWidget {
  const MalayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Malay Words',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const WordHome(),
    );
  }
}

class Word {
  final String id;
  final String malay;
  final String english;
  final String example;

  const Word({
    required this.id,
    required this.malay,
    required this.english,
    required this.example,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'malay': malay,
        'english': english,
        'example': example,
      };

  factory Word.fromJson(Map<String, dynamic> json) => Word(
        id: json['id']?.toString() ?? '',
        malay: json['malay']?.toString() ?? '',
        english: json['english']?.toString() ?? '',
        example: json['example']?.toString() ?? '',
      );
}

class WordHome extends StatefulWidget {
  const WordHome({super.key});

  @override
  State<WordHome> createState() => _WordHomeState();
}

class _WordHomeState extends State<WordHome> {
  static const _prefsKey = 'malay_words_v1';
  static const _savedKey = 'malay_saved_v1';

  final List<Word> _words = [];
  final Set<String> _savedIds = {};
  bool _loading = true;
  int _tab = 0;
  String _search = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    final saved = prefs.getStringList(_savedKey) ?? [];
    List<Word> loaded = [];

    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        loaded = list
            .map((e) => Word.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
      } catch (_) {}
    }

    if (loaded.isEmpty) loaded = _seedWords();

    if (!mounted) return;
    setState(() {
      _words
        ..clear()
        ..addAll(loaded);
      _savedIds
        ..clear()
        ..addAll(saved);
      _loading = false;
    });
    await _save();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _prefsKey,
      jsonEncode(_words.map((w) => w.toJson()).toList()),
    );
    await prefs.setStringList(_savedKey, _savedIds.toList());
  }

  List<Word> _seedWords() => const [
        Word(id: '1', malay: 'Masyarakat', english: 'Community', example: 'Masyarakat itu bekerjasama.',),
        Word(id: '2', malay: 'Faktor', english: 'Factor / cause', example: 'Apakah faktor pencemaran air?',),
        Word(id: '3', malay: 'Huraian', english: 'Explanation', example: 'Berikan huraian bagi isi tersebut.',),
        Word(id: '4', malay: 'Kepentingan', english: 'Importance', example: 'Nyatakan kepentingan menjaga alam sekitar.',),
        Word(id: '5', malay: 'Alam sekitar', english: 'Environment', example: 'Kita mesti menjaga alam sekitar.',),
        Word(id: '6', malay: 'Meningkatkan', english: 'To improve / increase', example: 'Kita perlu meningkatkan ilmu pengetahuan.',),
        Word(id: '7', malay: 'Mengurangkan', english: 'To reduce', example: 'Kitar semula dapat mengurangkan sampah.',),
        Word(id: '8', malay: 'Keselamatan', english: 'Safety', example: 'Utamakan keselamatan di jalan raya.',),
        Word(id: '9', malay: 'Penduduk', english: 'Residents / population', example: 'Penduduk kampung itu hidup aman.',),
        Word(id: '10', malay: 'Membina', english: 'To build', example: 'Mereka membina sebuah jambatan.',),
      ];

  List<Word> get _visibleWords {
    final source = _tab == 1
        ? _words.where((w) => _savedIds.contains(w.id)).toList()
        : _words;
    final q = _search.trim().toLowerCase();
    if (q.isEmpty) return source;
    return source.where((w) =>
        w.malay.toLowerCase().contains(q) ||
        w.english.toLowerCase().contains(q)).toList();
  }

  void _toggleSaved(Word word) {
    setState(() {
      if (!_savedIds.add(word.id)) _savedIds.remove(word.id);
    });
    _save();
  }

  Future<void> _addWord() async {
    final malay = TextEditingController();
    final english = TextEditingController();
    final example = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add a word'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: malay, decoration: const InputDecoration(labelText: 'Malay word')),
            TextField(controller: english, decoration: const InputDecoration(labelText: 'English meaning')),
            TextField(controller: example, decoration: const InputDecoration(labelText: 'Example sentence')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Add')),
        ],
      ),
    );
    if (result == true && malay.text.trim().isNotEmpty && english.text.trim().isNotEmpty) {
      setState(() {
        _words.insert(0, Word(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          malay: malay.text.trim(),
          english: english.text.trim(),
          example: example.text.trim(),
        ));
      });
      await _save();
    }
    malay.dispose();
    english.dispose();
    example.dispose();
  }

  void _showQuiz() {
    if (_words.length < 2) return;
    final random = Random();
    final question = _words[random.nextInt(_words.length)];
    final choices = <Word>{question};
    while (choices.length < min(4, _words.length)) {
      choices.add(_words[random.nextInt(_words.length)]);
    }
    final options = choices.toList()..shuffle();
    showDialog<void>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          String? picked;
          bool answered = false;
          return AlertDialog(
            title: const Text('Quick quiz'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('What does “${question.malay}” mean?',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                ...options.map((option) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: answered ? null : () => setDialogState(() {
                        picked = option.id;
                        answered = true;
                      }),
                      child: Text(option.english),
                    ),
                  ),
                )),
                if (answered)
                  Text(
                    picked == question.id
                        ? 'Correct! Great job 🎉'
                        : 'Not quite. The answer is: ${question.english}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: picked == question.id ? Colors.green : Colors.deepOrange,
                    ),
                  ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Malay Words 🇲🇾', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Take a quiz',
            onPressed: _showQuiz,
            icon: const Icon(Icons.quiz_outlined),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: TextField(
                    onChanged: (value) => setState(() => _search = value),
                    decoration: InputDecoration(
                      hintText: 'Search Malay or English...',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Expanded(child: _statCard('Words', '${_words.length}', Icons.menu_book)),
                      const SizedBox(width: 10),
                      Expanded(child: _statCard('Saved', '${_savedIds.length}', Icons.star)),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: _visibleWords.isEmpty
                      ? const Center(child: Text('No words found. Try another search.'))
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                          itemCount: _visibleWords.length,
                          itemBuilder: (context, index) {
                            final word = _visibleWords[index];
                            final saved = _savedIds.contains(word.id);
                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                title: Text(word.malay, style: const TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(word.english, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 15)),
                                      if (word.example.isNotEmpty) ...[
                                        const SizedBox(height: 5),
                                        Text(word.example, style: const TextStyle(fontStyle: FontStyle.italic)),
                                      ],
                                    ],
                                  ),
                                ),
                                trailing: IconButton(
                                  onPressed: () => _toggleSaved(word),
                                  icon: Icon(saved ? Icons.star : Icons.star_border,
                                      color: saved ? Colors.amber : null),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: _addWord,
              icon: const Icon(Icons.add),
              label: const Text('Add word'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() {
          _tab = value;
          _search = '';
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Words'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'Saved'),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ]),
          ],
        ),
      ),
    );
  }
}
